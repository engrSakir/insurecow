

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/fcss/homepage.css')); ?>" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="mt-5 mb-4 p-4">
    <div>
        <p class="p-greeting">Hi, <?php echo e(Auth::user()->name); ?>.</p>
        <p class="p-welcome-text">Welcome to InsureCow!</p>
    </div>

    <div class="row mt-5">
        <div class="d-lg-flex d-md-flex justify-content-center">

            <!--Cow Lists-->
            <div class="col-lg-4 col-md-6 mb-4 me-lg-5 me-md-4">
                <div class="card card-style">
                    <div class="p-2 card-block-top" style="background: #086343">
                        <h4 class="card-title">View Cow Lists </h4>
                    </div>
                    <img src="<?php echo e(asset('images/cow-list.png')); ?>" alt="Registered Cow" class="img-fluid img-card">
                    <div class="text-center p-4">

                        <a href="<?php echo e(route('farmer.registered.cattle')); ?>" class="btn card-button" style="background-color: #0f6848">Continue</a>

                    </div>
                </div>
            </div>

            <!--Field Agent Details-->
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card card-style">
                    <div class="p-2 card-block-top" style="background: #086343">
                        <h4 class="card-title">Medical Report Details </h4>
                    </div>
                    <img src="<?php echo e(asset('/images/field-agent.png')); ?>" alt="Insurance Claim" class="img-fluid  img-card">
                    <div class="text-center p-4">
                        <a href="<?php echo e(route('saved.medical.report')); ?>" class="btn card-button" style="background-color: #0f6848">Continue</a>
                    </div>
                </div>
           </div>
        </div>
    </div>

</section>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.farmer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insurecow\resources\views/farmer/home/index.blade.php ENDPATH**/ ?>