<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; InsureCow 2023 All Rights Reserved</span>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\insurecow\resources\views/inc/footer.blade.php ENDPATH**/ ?>