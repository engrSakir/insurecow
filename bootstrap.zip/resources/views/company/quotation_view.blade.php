@extends('layouts.company')

@section('content')

    <div style="padding: 20px">
        {!! $quotation->contents !!}
    </div>

@endsection
