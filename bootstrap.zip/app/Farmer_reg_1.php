<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Farmer_reg_1 extends Model
{
    protected $guarded = [];
}
